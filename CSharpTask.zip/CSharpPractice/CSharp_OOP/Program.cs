﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharp_OOP
{
    class Program
    {
        static void Main(string[] args)
        {
            Greetings();
            AverageOfTwoNum();
            AbsoluteNumber();
            CubeOfNumber();
            CheckOddEven();
            CheckEvenNum();
            MaxMinOfTwoNum();
            MuliplicationTable();
            CheckArmstrongNum();
            CheckPrimeNum();
            CheckLeapYear();
            PrimeNum1To100();
            PerameterAreaOfRhombus();
            DivisibleBY511();
            SimpleInterest();
            CompoundInterest();

            Console.ReadLine();
        }

        private static void CompoundInterest()
        {
            float PAmount = 10000, ROI = 4, Time_Period = 4, CIFuture = 0, CI = 0;

            var a = PAmount * (Math.Pow((1 + ROI / 100), Time_Period));
            CI = CIFuture - PAmount;
            Console.WriteLine("Total Amount {0}", a);
            Console.WriteLine("Compound Interest {0}", CI);
        }

        private static void SimpleInterest()
        {
            Console.WriteLine("Enter Principle Amount");
            int principle = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Rate of interest");
            double roi = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Enter duration in terms of year");
            int yr = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Simple interest is {0} ", principle * roi * yr / 100);
        }

        private static void DivisibleBY511()
        {
            Console.WriteLine("Enter an integer : ");
            int no = Convert.ToInt32(Console.ReadLine());
            if (no % 5 == 0 || no % 11 == 0)
            {
                Console.WriteLine("No is divisible by 5 or 11");
            }
        }

        private static void PerameterAreaOfRhombus()
        {
            int area, perimeter;
            Console.WriteLine("Enter Value first Diagonal ");
            int diagonal1 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Value first Diagonal ");
            int diagonal2 = Convert.ToInt32(Console.ReadLine());
            area = (diagonal1 * diagonal2) / 2;
            perimeter = (int)(2 * Math.Sqrt(Math.Pow(diagonal1, 2) +
                                            Math.Pow(diagonal2, 2)));

            Console.WriteLine("The area of rhombus with " +
                               "diagonals " + diagonal1 + " and " +
                                  diagonal2 + " is " + area + ".");

            Console.WriteLine("The perimeter of rhombus " +
                              "with diagonals " + diagonal1 + " and " +
                                 diagonal2 + " is " + perimeter + ".");
        }

        private static void PrimeNum1To100()
        {
            int i, Number = 1, count;
            while (Number <= 100)
            {
                count = 0;
                i = 2;
                while (i <= Number / 2)
                {
                    if (Number % i == 0)
                    {
                        count++;
                        break;
                    }
                    i++;
                }
                if (count == 0 && Number != 1)
                {
                    Console.WriteLine(Number);
                }
                Number++;

            }
        }

        private static void CheckLeapYear()
        {
            Console.WriteLine("Check whether a given year is leap year or not : ");
            int checkYear = Convert.ToInt32(Console.ReadLine());
            if ((checkYear % 400) == 0)
                Console.WriteLine("{0} is a leap year\n", checkYear);
            else if ((checkYear % 100) == 0)
                Console.WriteLine("{0} is not a leap year\n", checkYear);
            else if ((checkYear % 4) == 0)
                Console.WriteLine("{0} is not a leap year\n", checkYear);
            else
                Console.WriteLine("{0} is not a leap year\n", checkYear);
           
        }

        private static void CheckPrimeNum()
        {
            int times, tempNum = 0, flag = 0;

            Console.WriteLine("Enter a Number to check Prime : ");
            int number = Convert.ToInt32(Console.ReadLine());
            tempNum = number / 2;
            for (times = 2; times <= tempNum; times++)
            {
                if (number % times == 0)
                {
                    Console.WriteLine("Number is not a Prime Number");
                    flag = 1; break;
                }
            }
            if (flag == 0)
                Console.WriteLine("Number is Prime Number");
            Console.ReadLine();
        }

        private static void CheckArmstrongNum()
        {
            int armstrong = 0;
            Console.WriteLine("Enter a Number : ");
            int number = Convert.ToInt32(Console.ReadLine());
            int tempNum = number;
            while (number > 0)
            {
                int cube = number % 10;
                armstrong = armstrong + (cube * cube * cube);
                number = number / 10;
            }
            if (tempNum == armstrong)
                Console.WriteLine("This is an Armstrong Number");
            else
                Console.WriteLine("This is not an Armstrong Number");
            Console.ReadLine();
        }

        private static void MuliplicationTable()
        {
            Console.WriteLine("Enter an Integer : ");
            int table = Convert.ToInt32(Console.ReadLine());
            for (int times = 1; times <= 10; ++times)
            {
                Console.WriteLine("{0} * {1} = {2}\n", table, times, table * times);

            }
            Console.ReadLine();
        }

        private static void MaxMinOfTwoNum()
        {
            int largest;
            int smallest;
            Console.WriteLine("Number 1: ");
            int num1 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Number 2: ");
            int num2 = Convert.ToInt32(Console.ReadLine());
            if (num1 > num2)
            {
                largest = num1;
                smallest = num2;
            }
            else
            {
                largest = num2;
                smallest = num1;
            }
            Console.WriteLine("Largest number is : {0} \n Smallest  Number is : {1}", largest, smallest);
            Console.ReadLine();
        }

        private static void CheckEvenNum()
        {
            Console.WriteLine("Display all even numbers till :  ");
            int number = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Even numbers from 1 to {0} are : \n", number);
            for (int evenNum = 1; evenNum <= number; evenNum++)
            {
                if (evenNum % 2 == 0)
                { }
                Console.WriteLine("\n", evenNum);
            }
        }

        private static void CheckOddEven()
        {
            Console.WriteLine("Enter a number : ");
            int number = Convert.ToInt32(Console.ReadLine());
            if (number % 2 == 0)
                Console.WriteLine("{0} is Even Number \n", number);
            else
                Console.WriteLine("{0} is Odd Number \n", number);
        }

        private static void CubeOfNumber()
        {
            Console.WriteLine("Enter an interger number : \n");
            int number = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Number is {0} and the cube of the {1} is : {2}", number, number, number * number * number);
            Console.ReadLine();
        }

        private static void AbsoluteNumber()
        {
            Console.WriteLine("Enter a Number : ");
            int number = Convert.ToInt32(Console.ReadLine());

            if (number < 0)
                number = number * -1;
            Console.WriteLine("Absolute value is " + number);
            Console.Read();
        }

        private static void AverageOfTwoNum()
        {
            Console.WriteLine("Number 1: ");
            int num1 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Number 2: ");
            int num2 = Convert.ToInt32(Console.ReadLine());
            int average = (num1 + num2) / 2;
            Console.WriteLine(average);
            Console.ReadLine();
        }

        private static void Greetings()
        {
            Console.WriteLine("Please Enter your name:");
            string fullName = Console.ReadLine();
            Console.WriteLine("Hello.. " + fullName + " Welcome to DishTV!!! ");
        }
    }
}
